import * as React from 'react'
import {Link} from '@reach/router';

import {appData} from "@api/api";

import {Button} from "@style-guide/components";

//import {ActionBar} from "actionbar";

const Project = (props:any)=>{

    // const {projectList =[]} = props;
    
    const projectList = appData.project;
    const removeProject = () => {
        appData.project.splice(0,1);
        console.log(appData)
    }

    const setProjectName = (e) => {
        appData.project.name = e.target.value;
    }
return (
   <div className="project-container">
       <h1>Projects</h1>
       {
       projectList.map((item,idx) => {
           return (
               <div key={idx} className="project">
                   {item.name}
               </div>
           )
       })
    }
    <br/>
    <button onClick={removeProject}>Remove</button>
    <div> 
        set Project Name : <input type="text" onChange={setProjectName} />
    </div>
    <Link to="/"> <Button label="Back to home" /></Link>


 </div>
 );
};
export default Project;
window.myapp = {
    path: "/",
    setPath: (path) => {
      (window.myapp.path = path), window.dispatchEvent(new Event("onSetPath"));
    }
  };
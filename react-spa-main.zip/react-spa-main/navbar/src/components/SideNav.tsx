import * as React from "react";
import { FaReact, FaRegAddressBook } from "react-icons/fa";
import { Link } from "@reach/router";

const SideNav = (props: any) => {
  const { myapp: { setPath = () => {} } = {} } = window as any;
  console.log(window);
  const onDevClick = () => {
    //router to developer page and statemanagement
  };

  React.useEffect(() => {
    window.addEventListener("onSetPath", () => {});
  }, []);

  const onProjectclick = () => {
    props.callBackProject;
  };

  return (
    <div className="nav-container">
      <ul>
        <li>
          <Link to="/">
            <FaReact />
          </Link>
        </li>
        <li>
          <Link to="/" onClick={() => setPath("/developer")}>
            <FaRegAddressBook />
          </Link>
        </li>

        <li>
          <Link to="/" onClick={() => setPath("/project")}>
            Project
          </Link>
        </li>
      </ul>
    </div>
  );
};
export default SideNav;

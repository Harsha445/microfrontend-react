import React, { useEffect, useState} from 'react';

import {appData} from  "@api/api";
//import  {ActionBar} from "actionbar/src/ActionBar";


const Developer =({getData})=>{
  console.log("working")
  const btnHander = ()=>{
    getData('You clicked the button')
  }
console.log(appData)

const onBold = () => {
  console.log("bold")
}

const onItalic = () => {
  console.log("italic")
}
 
  return(
    <div>
      <h2>Developer page</h2>
  Number of Project: {appData.project.length}
  Project Name : {appData.project.name}
  <br/>
      <button onClick={btnHander}> click me</button>


    </div>
  )
};

export default Developer;
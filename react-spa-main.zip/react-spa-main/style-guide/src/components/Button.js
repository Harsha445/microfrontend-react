import React from 'react';
import  "./Button.css"

export const Button = (props) => {
    const {
        label='',
        onClick = () => {}
    } = props;

    return(
        <div className='btn' onClick={onClick}>
            {label}
        </div>
    )
}
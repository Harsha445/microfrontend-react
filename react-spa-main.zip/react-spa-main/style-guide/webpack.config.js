const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-react");
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');

module.exports = (webpackConfigEnv, argv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: "style-guide",
    projectName: "components",
    webpackConfigEnv,
    argv,
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    externals: [/^rxjs\/?.*$/],
    plugins: [
      new ModuleFederationPlugin({
        name: "style-guide",
        library: { type: 'system' },
        filename: "styleComponents.js",
        exposes: {
          "./style-guide": "./src/style-guide-components.js",
        },
        shared: ['react', 'react-dom'] // { '@fluentui/react': { singleton: true, eager: true } }
      })
    ]
  });
};
